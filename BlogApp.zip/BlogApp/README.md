This is the Blog Application
